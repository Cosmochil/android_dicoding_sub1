package com.example.gitprofile

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView

class ProfileActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)
        val tvProfileImage: ImageView = findViewById(R.id.profile_avatar)
        val tvProfileName: TextView = findViewById(R.id.profile_name)
        val tvProfileUsername: TextView = findViewById(R.id.profile_username)
        val tvLocation: TextView = findViewById(R.id.profile_location)
        val tvFollower: TextView = findViewById(R.id.profile_follower)
        val tvFollowing: TextView = findViewById(R.id.profile_following)
        val tvRepo: TextView = findViewById(R.id.profile_repo)

        val data = intent.getParcelableExtra<User>("DATA")
        if (data != null) {
            tvProfileImage.setImageResource(data.photo.toInt())

        }

        tvProfileName.text = data?.name
        tvProfileUsername.text = data?.username
        tvLocation.text = data?.location
        tvFollower.text = data?.follower
        tvFollowing.text = data?.following
        tvRepo.text = data?.repo
    }

}
