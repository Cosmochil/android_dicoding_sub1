package com.example.gitprofile

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class User(
    var name: String,
    var company: String,
    var photo: Int,
    var username: String,
    var location: String,
    var repo: String,
    var follower: String,
    var following: String,

    ) : Parcelable
