package com.example.gitprofile

import android.content.Intent
import android.content.res.Configuration
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var rvGitUsers: RecyclerView
    private val list = ArrayList<User>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        rvGitUsers = findViewById(R.id.git_users)
        rvGitUsers.setHasFixedSize(true)

        list.addAll(userList)
        showRecyclerList()
    }

    private val userList: ArrayList<User>
        get() {
            val dataName = resources.getStringArray(R.array.name)
            val dataCompany = resources.getStringArray(R.array.company)
            val userAvatar = resources.obtainTypedArray(R.array.avatar)
            val dataUsername = resources.getStringArray(R.array.username)
            val userLoc = resources.getStringArray(R.array.location)
            val userRepo = resources.getStringArray(R.array.repository)
            val userFollower = resources.getStringArray(R.array.followers)
            val userFollowing = resources.getStringArray(R.array.following)
            val userList = ArrayList<User>()
            for (i in dataName.indices) {
                val user = User(
                    dataName[i],
                    dataCompany[i],
                    userAvatar.getResourceId(i, -1),
                    dataUsername[i],
                    userLoc[i],
                    userFollower[i],
                    userRepo[i],
                    userFollowing[i]
                )
                userList.add(user)
            }
            return userList
        }

    private fun showRecyclerList() {
        if (applicationContext.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            rvGitUsers.layoutManager = GridLayoutManager(this, 2)
        }else {
            rvGitUsers.layoutManager = LinearLayoutManager(this)
        }

        val userListAdapter = UserListAdapter(list)
        rvGitUsers.adapter = userListAdapter

        userListAdapter.setOnItemClickCallback(object : UserListAdapter.OnItemClickCallback {
            override fun onItemClicked(data: User) {
                val toProfileIntent = Intent(this@MainActivity, ProfileActivity::class.java)
                toProfileIntent.putExtra("DATA", data)
                startActivity(toProfileIntent)
            }
        })
    }

}